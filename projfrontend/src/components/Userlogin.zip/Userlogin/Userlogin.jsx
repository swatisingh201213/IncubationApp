import React from 'react'
import "bootstrap/dist/css/bootstrap.min.css";
import "./Userlogin.css"
import userIcon from "./user.png"
import backimg from "./back.jpg"



function Userlogin() {
    return (
        <>
            <div className="container" id="User-login-section">
                <div className="row">
                    <div className="col-md-8 img-fluid p-1 showcase-img-background">
                        <img src={backimg} alt="backgroundimg" className="img-fluid" width="100%" />
                    </div>
                    <div className="col-12 col-md-4 login-modal">
                        <div className="avatar-login text-center">
                            <img src={userIcon} alt="userAvatar" />
                        </div>
                        <h3 className="text-center">Member Login </h3>

                        <form>
                            <div className="row mb-4">
                                <div className="col-md-12 form-group">
                                    <i className="fa fa-user"></i>
                                    <input type="email" className="form-control" id="inputEmail3" placeholder="Email" />
                                </div>
                            </div>
                            <div className="row ">
                                <div className="col-md-12 form-group">
                                    <i className="fa fa-lock"></i>
                                    <input type="password" className="form-control" id="inputPassword3" placeholder="Password" />
                                </div>
                            </div>
                            <div className="form-group text-right">
                                <a href="#nmn" className="text-dark" >Forgot Password?</a>
                            </div>
                            <div className="text-center">
                                <button type="submit" className="btn btn-login btn-lg btn-block">Login</button>
                            </div>


                        </form>

                    </div>
                </div>

            </div>



        </>
    )
}

export default Userlogin
